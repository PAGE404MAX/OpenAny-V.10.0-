@echo off
REM Launch OpenAny from source without building an installer.
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo [!] Install Node.js from https://nodejs.org & pause & exit /b 1)
if not exist node_modules ( echo Installing dependencies... & call npm install --no-audit --no-fund )
call npx electron .
