const { contextBridge, ipcRenderer, webUtils } = require('electron');

contextBridge.exposeInMainWorld('openany', {
  readFile: (p) => ipcRenderer.invoke('read-file', p),
  pickFile: () => ipcRenderer.invoke('pick-file'),
  saveAs: (defaultName, data) => ipcRenderer.invoke('save-as', { defaultName, data }),
  openPaths: (paths) => ipcRenderer.send('open-paths', paths),
  newWindow: () => ipcRenderer.send('new-window'),
  reveal: (p) => ipcRenderer.send('reveal', p),
  openExternalApp: (p) => ipcRenderer.send('open-external-app', p),
  setTitle: (t) => ipcRenderer.send('set-title', t),
  uninstall: () => ipcRenderer.send('uninstall'),
  // resolve a real filesystem path from a dropped File object (Electron >= 32 safe)
  pathForFile: (file) => {
    try { if (webUtils && webUtils.getPathForFile) return webUtils.getPathForFile(file); } catch (_) {}
    return file.path || null;
  },
  onOpenFile: (cb) => ipcRenderer.on('open-file', (_e, p) => cb(p)),
  onFileChanged: (cb) => ipcRenderer.on('file-changed', () => cb()),
  onMenu: (cb) => ipcRenderer.on('menu', (_e, action) => cb(action))
});
