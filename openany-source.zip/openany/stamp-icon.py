#!/usr/bin/env python3
"""Embed assets/icon.png into release/win-unpacked/OpenAny.exe and rename
version strings from Electron -> OpenAny. Pure-python; no Wine/rcedit."""
import struct, pefile
from PIL import Image

EXE = 'release/win-unpacked/OpenAny.exe'
src = Image.open('assets/icon.png').convert('RGBA')

def dib(size):
    im = src.resize((size, size), Image.LANCZOS); px = im.load()
    out = bytearray(struct.pack('<IiiHHIIiiII', 40, size, size*2, 1, 32, 0, size*size*4, 0,0,0,0))
    for y in range(size-1, -1, -1):
        for x in range(size):
            r,g,b,a = px[x,y]; out += bytes((b,g,r,a))
    out += b'\x00' * (((size+31)//32)*4 * size)
    return bytes(out)

pe = pefile.PE(EXE, fast_load=True)
pe.parse_data_directories([pefile.DIRECTORY_ENTRY['IMAGE_DIRECTORY_ENTRY_RESOURCE']])
import mmap
fh = open(EXE, 'r+b')
buf = mmap.mmap(fh.fileno(), 0)
slots = []
for e in pe.DIRECTORY_ENTRY_RESOURCE.entries:
    if e.id == 3:
        for ent in e.directory.entries:
            for d in ent.directory.entries:
                slots.append((ent.id, d.data.struct.OffsetToData, d.data.struct.Size))
slots.sort(key=lambda s: s[2])
placed = []
for (rid, rva, cap), dim in zip(slots, [16,32,48,64]):
    blob = dib(dim); assert len(blob) <= cap
    off = pe.get_offset_from_rva(rva)
    buf[off:off+cap] = blob + b'\x00'*(cap-len(blob))
    placed.append((rid, dim, len(blob)))
for e in pe.DIRECTORY_ENTRY_RESOURCE.entries:
    if e.id == 14:
        for ent in e.directory.entries:
            for d in ent.directory.entries:
                go = pe.get_offset_from_rva(d.data.struct.OffsetToData)
                g = bytearray(buf[go:go+d.data.struct.Size])
                for i, (rid, dim, blen) in enumerate(placed):
                    p = 6 + i*14
                    g[p] = g[p+1] = dim if dim < 256 else 0
                    g[p+2] = g[p+3] = 0
                    struct.pack_into('<HHI', g, p+4, 1, 32, blen)
                    struct.pack_into('<H', g, p+12, rid)
                buf[go:go+len(g)] = bytes(g)
    if e.id == 16:
        for ent in e.directory.entries:
            for d in ent.directory.entries:
                off = pe.get_offset_from_rva(d.data.struct.OffsetToData)
                sz = d.data.struct.Size; blk = bytearray(buf[off:off+sz]); txt = bytes(blk)
                for old, new in [("Electron","OpenAny"), ("electron.exe","OpenAny.exe"),
                                 ("GitHub, Inc.","OpenAny")]:
                    o = old.encode('utf-16-le')+b'\x00\x00'
                    n = new.encode('utf-16-le')+b'\x00\x00'
                    n += b'\x00'*(len(o)-len(n))
                    i = 0
                    while True:
                        i = txt.find(o, i)
                        if i < 0: break
                        blk[i:i+len(o)] = n; txt = bytes(blk); i += len(o)
                buf[off:off+sz] = bytes(blk)
buf.flush(); buf.close(); fh.close()
print("icon + metadata stamped")
