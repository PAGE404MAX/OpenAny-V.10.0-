#!/bin/bash
# Rebuilds OpenAny-Setup.exe on Linux without Wine.
set -e
cd "$(dirname "$0")"
NS="$HOME/.cache/electron-builder/nsis/nsis-3.0.4.1"
# Linux can't run rcedit; skip it here and stamp the icon with stamp-icon.py instead
npx electron-builder --win --x64 --dir -c.win.signAndEditExecutable=false
python3 stamp-icon.py
NSISDIR=$NS NSISCONFDIR=$NS "$NS/linux/makensis" -NOCD \
  -DOUTFILE="$PWD/release/OpenAny-Setup-1.0.0.exe" \
  -DPAYLOAD="$PWD/release/win-unpacked" \
  -DICONFILE="$PWD/assets/icon.ico" \
  installer.nsi
echo "-> release/OpenAny-Setup-1.0.0.exe"
