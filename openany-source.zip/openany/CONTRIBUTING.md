# Contributing to OpenAny

Thanks for taking a look. This is a small, dependency-light project and it aims
to stay that way.

## Ground rules

1. **No runtime dependencies.** The app ships with zero npm packages at runtime —
   only Electron itself. Every viewer (Markdown, CSV, JSON, ZIP, fonts, hex) is
   hand-written in `src/viewer.js`. Please don't add a library to solve something
   that's ~50 lines of plain JavaScript.
2. **Greyscale only.** The UI uses a 10-step grey ramp (`--g0` … `--g9`) and
   nothing else. No accent colours, no coloured emoji. There's a test for this —
   see below.
3. **Offline forever.** The CSP is `default-src 'none'`. The app must never make
   a network request. No telemetry, no update checks, no remote fonts.
4. **Security posture stays put.** `contextIsolation: true`, `nodeIntegration:
   false`. The renderer talks to the filesystem only through the explicit IPC
   channels in `src/preload.js`.

## Getting set up

```bash
git clone https://github.com/YOUR-USERNAME/openany.git
cd openany
npm install
npm start
```

On Windows you can double-click `run-dev.cmd` instead.

## Project layout

```
src/main.js      Electron main process — windows, file watching, IPC, menus
src/preload.js   contextBridge API surface (the only renderer↔main door)
src/index.html   app shell: sidebar + toolbar + stage
src/viewer.css   the entire greyscale theme
src/viewer.js    format detection + every viewer
```

`src/viewer.js` is the file you'll usually touch. Its shape:

| Section | What it does |
|---|---|
| `EXT` / `kindOf` / `sniff` / `looksText` | decide what a file *is* |
| `buildBar` | the toolbar, rebuilt per file |
| `viewImage` … `viewHex` | one function per format |
| `renderSidebar` | the recent-files panel |
| `load` / `render` | the pipeline that ties it together |

## Adding a new viewer

1. Add your extensions to the `EXT` map near the top of `viewer.js`.
2. Write a `viewYourThing()` function that fills `stage.innerHTML`.
   Use `tool('<button>…</button>')` to add toolbar buttons.
3. Add a `case` to the `switch (kind)` block in `render()`.
4. If the format has a magic-byte signature, add it to `sniff()` so
   extensionless files work too.
5. Style it in `viewer.css` using only the `--g0`…`--g9` variables.

## Before you open a PR

**Check the greyscale rule.** Screenshot your view and verify no pixel has a
colour channel spread:

```python
from PIL import Image
im = Image.open('shot.png').convert('RGB')
worst = max(max(p) - min(p) for p in im.getdata())
print('max RGB spread:', worst)   # must be 0
```

**Check for emoji.** Coloured emoji render in full colour on Windows even if
they look grey on Linux — this has bitten us before:

```bash
python3 -c "s=open('src/viewer.js',encoding='utf-8').read(); \
print('emoji:', len([c for c in s if ord(c)>0x1F000]))"   # must be 0
```

**Syntax check:**

```bash
node -e "new Function(require('fs').readFileSync('src/viewer.js','utf8'))"
node -e "new Function(require('fs').readFileSync('src/main.js','utf8'))"
```

**Actually open some files.** Every viewer regression in this project's history
came from a change that looked obviously correct and was never run. Open at
least: an image, a Markdown file, a CSV, a JSON, a ZIP, and a binary.

## Building installers

- **Windows:** `npm run dist`, or double-click `build-windows.cmd`
- **Linux (no Wine):** `./build-installer-linux.sh` — packages the app, runs
  `stamp-icon.py` to embed the icon via a pure-Python PE editor, then calls the
  NSIS Linux binary against `installer.nsi`
- **CI:** pushing a `v*` tag builds on `windows-latest` and publishes a Release

## Good first issues

- **Extract ZIP entries.** Currently archives are listed but not decompressed.
  `DecompressionStream('deflate-raw')` is built into Chromium and would let you
  click an entry to view it.
- **Syntax highlighting** that respects greyscale — weight and italics instead
  of hue.
- **macOS / Linux builds.** The source is cross-platform; only the installer is
  Windows-specific.
- **More magic-byte signatures** in `sniff()`.

## License

By contributing you agree your work is released under the [MIT License](LICENSE).
