// OpenAny — Electron main process
// One window per file. Window title = file name.
const { app, BrowserWindow, ipcMain, dialog, shell, Menu, nativeTheme } = require('electron');
const path = require('path');
const fs = require('fs');
const fsp = fs.promises;
const os = require('os');
const { spawn } = require('child_process');

const MAX_BYTES = 512 * 1024 * 1024; // hard ceiling
const windows = new Map();           // BrowserWindow.id -> { filePath, watcher }

// Single instance: a second launch (e.g. double-clicking another file)
// forwards its argv to us instead of starting a new process.
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', (_e, argv) => {
    const files = filesFromArgv(argv);
    if (files.length) files.forEach(f => openFileWindow(f));
    else createWindow(null);
  });
}

function filesFromArgv(argv) {
  return argv.slice(1).filter(a => {
    if (a.startsWith('-')) return false;
    if (a === '.' || a.endsWith('app.asar')) return false;
    try { return fs.statSync(a).isFile(); } catch (_) { return false; }
  });
}

// macOS / file-drop-on-icon
const pendingOpen = [];
app.on('open-file', (e, p) => {
  e.preventDefault();
  if (app.isReady()) openFileWindow(p); else pendingOpen.push(p);
});

function createWindow(filePath) {
  const win = new BrowserWindow({
    width: 1100,
    height: 780,
    minWidth: 480,
    minHeight: 360,
    show: false,
    backgroundColor: '#0a0a0a',
    title: filePath ? path.basename(filePath) : 'OpenAny',
    icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false
    }
  });

  // Never let the page override the title we set from the file name.
  win.on('page-title-updated', e => e.preventDefault());

  windows.set(win.id, { filePath: filePath || null, watcher: null });

  win.loadFile(path.join(__dirname, 'index.html'));
  win.once('ready-to-show', () => win.show());

  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  win.webContents.on('will-navigate', e => e.preventDefault());

  win.on('closed', () => {
    const rec = windows.get(win.id);
    if (rec && rec.watcher) { try { rec.watcher.close(); } catch (_) {} }
    windows.delete(win.id);
  });

  return win;
}

function openFileWindow(filePath) {
  // If this file already has a window, focus it instead of duplicating.
  for (const [id, rec] of windows) {
    if (rec.filePath && path.resolve(rec.filePath) === path.resolve(filePath)) {
      const w = BrowserWindow.fromId(id);
      if (w) { if (w.isMinimized()) w.restore(); w.focus(); return w; }
    }
  }
  // Reuse an empty welcome window if one is focused/available.
  const focused = BrowserWindow.getFocusedWindow();
  if (focused && windows.get(focused.id) && !windows.get(focused.id).filePath) {
    setWindowFile(focused, filePath);
    return focused;
  }
  const win = createWindow(filePath);
  win.webContents.once('did-finish-load', () => setWindowFile(win, filePath));
  return win;
}

function setWindowFile(win, filePath) {
  const rec = windows.get(win.id);
  if (!rec) return;
  if (rec.watcher) { try { rec.watcher.close(); } catch (_) {} rec.watcher = null; }
  rec.filePath = filePath;
  win.setTitle(path.basename(filePath) + '  —  OpenAny');
  if (process.platform === 'darwin') win.setRepresentedFilename(filePath);
  win.webContents.send('open-file', filePath);

  // live reload on external change (debounced)
  try {
    let t = null;
    rec.watcher = fs.watch(filePath, () => {
      clearTimeout(t);
      t = setTimeout(() => { if (!win.isDestroyed()) win.webContents.send('file-changed'); }, 180);
    });
  } catch (_) {}
}

/* ---------------- IPC ---------------- */

ipcMain.handle('read-file', async (_e, filePath) => {
  const st = await fsp.stat(filePath);
  if (!st.isFile()) throw new Error('Not a file');
  if (st.size > MAX_BYTES) {
    return { meta: metaOf(filePath, st), tooBig: true, maxBytes: MAX_BYTES };
  }
  const buf = await fsp.readFile(filePath);
  return { meta: metaOf(filePath, st), tooBig: false, bytes: buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength) };
});

function metaOf(filePath, st) {
  return {
    name: path.basename(filePath),
    dir: path.dirname(filePath),
    path: filePath,
    size: st.size,
    mtime: st.mtimeMs,
    ctime: st.birthtimeMs || st.ctimeMs
  };
}

ipcMain.handle('pick-file', async (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showOpenDialog(win, {
    title: 'Open file',
    properties: ['openFile', 'multiSelections'],
    buttonLabel: 'Open'
  });
  if (r.canceled || !r.filePaths.length) return null;
  r.filePaths.forEach((p, i) => { if (i === 0) setWindowFile(win, p); else openFileWindow(p); });
  return r.filePaths[0];
});

ipcMain.on('open-paths', (e, paths) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const rec = windows.get(win.id);
  paths.forEach((p, i) => {
    if (i === 0 && rec && !rec.filePath) setWindowFile(win, p);
    else openFileWindow(p);
  });
});

ipcMain.on('new-window', () => createWindow(null));
ipcMain.on('reveal', (_e, p) => shell.showItemInFolder(p));
ipcMain.on('open-external-app', (_e, p) => shell.openPath(p));
ipcMain.on('set-title', (e, t) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  if (!win) return;
  win.setTitle(t);
  const rec = windows.get(win.id);
  if (rec && t === 'OpenAny') {
    // back at the welcome screen: forget the file so a new drop reuses this window
    if (rec.watcher) { try { rec.watcher.close(); } catch (_) {} rec.watcher = null; }
    rec.filePath = null;
  }
});
ipcMain.handle('save-as', async (e, { defaultName, data }) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const r = await dialog.showSaveDialog(win, { defaultPath: defaultName });
  if (r.canceled || !r.filePath) return false;
  await fsp.writeFile(r.filePath, Buffer.from(data));
  return true;
});

/* ---------------- uninstall ---------------- */
// Removes the app, its shortcuts, all registry entries, saved settings,
// and (optionally) any other copies found on disk.
ipcMain.on('uninstall', async (e) => {
  const win = BrowserWindow.fromWebContents(e.sender);
  const exePath = app.getPath('exe');
  const installDir = path.dirname(exePath);
  const uninstaller = path.join(installDir, 'Uninstall.exe');
  const hasUninstaller = app.isPackaged && fs.existsSync(uninstaller);

  const bullets = [
    hasUninstaller
      ? 'The installed app:\n      ' + installDir
      : 'This copy of the app:\n      ' + installDir,
    'Settings and recent-file list:\n      ' + app.getPath('userData'),
    'Start menu and desktop shortcuts',
    'The "Open with OpenAny" menu entry and file associations'
  ];

  // Safety: never run this against a dev checkout. Unpackaged, installDir is
  // node_modules/electron/dist and userData is the shared Electron profile —
  // deleting either would wreck the developer's machine, not uninstall OpenAny.
  if (!app.isPackaged) {
    await dialog.showMessageBox(win, {
      type: 'info',
      buttons: ['OK'],
      title: 'Uninstall unavailable',
      message: 'This is a development build.',
      detail: 'Uninstall only works in the installed app, so it can never delete '
            + 'a source checkout or Electron itself by mistake.\n\n'
            + 'To remove a dev copy, just delete its folder.'
    });
    return;
  }

  const res = await dialog.showMessageBox(win, {
    type: 'warning',
    buttons: ['Cancel', 'Uninstall OpenAny'],
    defaultId: 0,
    cancelId: 0,
    noLink: true,
    title: 'Uninstall OpenAny',
    message: 'Permanently remove OpenAny from this computer?',
    detail:
      'This will delete:\n\n  \u2022 ' + bullets.join('\n\n  \u2022 ') +
      '\n\nYour own files are never touched \u2014 only OpenAny itself.\n' +
      'This cannot be undone.',
    checkboxLabel: 'Also find and remove other copies (portable builds, Downloads)',
    checkboxChecked: false
  });

  if (res.response !== 1) return;

  const alsoCopies = !!res.checkboxChecked;
  const userData = app.getPath('userData');

  // Build a batch script that runs AFTER we exit, so it can delete our own exe.
  const lines = [
    '@echo off',
    'chcp 65001 >nul',
    'ping 127.0.0.1 -n 3 >nul',           // wait for this process to die
    'taskkill /F /IM OpenAny.exe >nul 2>&1',
    'ping 127.0.0.1 -n 2 >nul'
  ];

  if (hasUninstaller) {
    // Run the NSIS uninstaller silently; _?= makes it run in-place so we can wait.
    lines.push('"' + uninstaller + '" /S _?=' + installDir);
    lines.push('ping 127.0.0.1 -n 4 >nul');
    lines.push('del /f /q "' + uninstaller + '" >nul 2>&1');
    lines.push('rmdir /s /q "' + installDir + '" >nul 2>&1');
  } else {
    // Portable / dev copy: just remove the folder we live in.
    lines.push('rmdir /s /q "' + installDir + '" >nul 2>&1');
  }

  // Settings, caches, logs — only if this really is OpenAny's own profile dir
  if (/[\\/]OpenAny$/i.test(userData)) {
    lines.push('rmdir /s /q "' + userData + '" >nul 2>&1');
  }
  lines.push('rmdir /s /q "' + path.join(app.getPath('appData'), 'OpenAny') + '" >nul 2>&1');

  // Shortcuts
  const sm = path.join(app.getPath('appData'), 'Microsoft', 'Windows', 'Start Menu', 'Programs');
  lines.push('rmdir /s /q "' + path.join(sm, 'OpenAny') + '" >nul 2>&1');
  lines.push('del /f /q "' + path.join(sm, 'OpenAny.lnk') + '" >nul 2>&1');
  lines.push('del /f /q "' + path.join(app.getPath('desktop'), 'OpenAny.lnk') + '" >nul 2>&1');

  // Registry: associations, ProgID, context menu, uninstall entry
  const regKeys = [
    'HKCU\\Software\\Classes\\OpenAny.Document',
    'HKCU\\Software\\Classes\\*\\shell\\OpenAny',
    'HKCU\\Software\\Classes\\Applications\\OpenAny.exe',
    'HKCU\\Software\\OpenAny',
    'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\OpenAny'
  ];
  regKeys.forEach(k => lines.push('reg delete "' + k + '" /f >nul 2>&1'));

  // Remove OpenAny from each extension's OpenWithProgids
  const exts = ['zip','jar','epub','docx','xlsx','pptx','ttf','otf','woff','woff2',
                'csv','tsv','json','jsonl','ndjson','md','log','bin','dat','db',
                'sqlite','toml','ini','srt','vtt','geojson'];
  exts.forEach(x => lines.push(
    'reg delete "HKCU\\Software\\Classes\\.' + x + '\\OpenWithProgids" /v "OpenAny.Document" /f >nul 2>&1'));

  if (alsoCopies) {
    // Look for other OpenAny installs/portable copies in the usual places.
    const roots = [
      path.join(app.getPath('home'), 'Downloads'),
      app.getPath('desktop'),
      path.join(app.getPath('home'), 'Documents'),
      path.join(process.env.LOCALAPPDATA || '', 'Programs')
    ].filter(Boolean);
    roots.forEach(r => {
      lines.push('for /d %%D in ("' + r + '\\*OpenAny*") do rmdir /s /q "%%D" >nul 2>&1');
      lines.push('del /f /q "' + r + '\\OpenAny*.exe" >nul 2>&1');
      lines.push('del /f /q "' + r + '\\OpenAny*.zip" >nul 2>&1');
    });
  }

  // Refresh Explorer so icons/menus update, then delete this script
  lines.push('powershell -NoProfile -Command "$s=New-Object -ComObject Shell.Application; $null" >nul 2>&1');
  lines.push('del /f /q "%~f0" >nul 2>&1');

  const bat = path.join(os.tmpdir(), 'openany-uninstall-' + Date.now() + '.bat');
  try {
    fs.writeFileSync(bat, lines.join('\r\n'), 'utf8');
  } catch (err) {
    dialog.showErrorBox('Uninstall failed', 'Could not create the uninstall script.\n\n' + err.message);
    return;
  }

  const child = spawn('cmd.exe', ['/c', bat], {
    detached: true,
    stdio: 'ignore',
    windowsHide: true
  });
  child.unref();

  // Give the script a moment to start, then quit so it can delete us.
  setTimeout(() => { app.exit(0); }, 400);
});

/* ---------------- menu ---------------- */
function buildMenu() {
  const template = [
    {
      label: 'File',
      submenu: [
        { label: 'Open…', accelerator: 'CmdOrCtrl+O', click: (i, w) => w && w.webContents.send('menu', 'open') },
        { label: 'New Window', accelerator: 'CmdOrCtrl+N', click: () => createWindow(null) },
        { type: 'separator' },
        { label: 'Reveal in Explorer', accelerator: 'CmdOrCtrl+Shift+R', click: (i, w) => w && w.webContents.send('menu', 'reveal') },
        { label: 'Open in Default App', click: (i, w) => w && w.webContents.send('menu', 'external') },
        { type: 'separator' },
        { label: 'Close Window', accelerator: 'CmdOrCtrl+W', role: 'close' },
        { label: 'Quit', accelerator: 'CmdOrCtrl+Q', role: 'quit' },
        { type: 'separator' },
        { label: 'Uninstall OpenAny…', click: (i, w) => w && w.webContents.send('menu', 'uninstall') }
      ]
    },
    {
      label: 'Go',
      submenu: [
        { label: 'Back', accelerator: 'Alt+Left', click: (i, w) => w && w.webContents.send('menu', 'back') },
        { label: 'Forward', accelerator: 'Alt+Right', click: (i, w) => w && w.webContents.send('menu', 'forward') },
        { label: 'Home (file list)', accelerator: 'Esc', click: (i, w) => w && w.webContents.send('menu', 'home') },
        { type: 'separator' },
        { label: 'Clear Recent List', click: (i, w) => w && w.webContents.send('menu', 'clear-recent') }
      ]
    },
    {
      label: 'View',
      submenu: [
        { label: 'Toggle File List', accelerator: 'CmdOrCtrl+B', click: (i, w) => w && w.webContents.send('menu', 'toggle-sidebar') },
        { type: 'separator' },
        { label: 'Reload File', accelerator: 'CmdOrCtrl+R', click: (i, w) => w && w.webContents.send('file-changed') },
        { label: 'Hex Dump', accelerator: 'CmdOrCtrl+H', click: (i, w) => w && w.webContents.send('menu', 'hex') },
        { label: 'Find', accelerator: 'CmdOrCtrl+F', click: (i, w) => w && w.webContents.send('menu', 'find') },
        { type: 'separator' },
        { role: 'zoomIn', accelerator: 'CmdOrCtrl+Plus' },
        { role: 'zoomOut' },
        { role: 'resetZoom' },
        { type: 'separator' },
        { role: 'togglefullscreen' },
        { label: 'Developer Tools', accelerator: 'F12', role: 'toggleDevTools' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'About OpenAny',
          click: (i, w) => dialog.showMessageBox(w, {
            type: 'info',
            title: 'About OpenAny',
            message: 'OpenAny ' + app.getVersion(),
            detail: 'A universal file viewer.\nImages, SVG, video, audio, PDF, text & code, Markdown,\nCSV/TSV, JSON/JSONL, ZIP-family archives, fonts,\nand a hex dump for everything else.\n\nEverything is read locally. No network access.',
            buttons: ['OK'],
            icon: path.join(__dirname, 'icon.png')
          })
        }
      ]
    }
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

app.whenReady().then(() => {
  nativeTheme.themeSource = 'dark';
  buildMenu();
  const files = filesFromArgv(process.argv).concat(pendingOpen);
  if (files.length) files.forEach(f => openFileWindow(f));
  else createWindow(null);

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow(null);
  });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
