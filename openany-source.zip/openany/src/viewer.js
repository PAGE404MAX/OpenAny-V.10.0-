/* OpenAny desktop — renderer */
(function () {
  const API = window.openany;
  const bar = document.getElementById('bar');
  const stage = document.getElementById('stage');
  const veil = document.getElementById('veil');
  const side = document.getElementById('side');
  const sidelist = document.getElementById('sidelist');
  let META = null, BYTES = null, CURPATH = null, wrap = false, lastSearch = null;
  let HISTORY = [], HPOS = -1;   // back/forward stack (browser semantics)
  let RECENT = [];               // every file opened, newest last, never truncated
  let SIDEBAR = true;            // sidebar visible?

const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const ext = n => { const i = n.lastIndexOf('.'); return i < 1 ? '' : n.slice(i + 1).toLowerCase(); };
  const fmtSize = b => {
    if (b < 1024) return b + ' B';
    const u = ['KB', 'MB', 'GB', 'TB']; let i = -1;
    do { b /= 1024; i++; } while (b >= 1024 && i < 3);
    return b.toFixed(b < 10 ? 2 : 1) + ' ' + u[i];
  };

  const EXT = {
    image: 'png jpg jpeg gif webp bmp ico avif apng jfif'.split(' '),
    svg: ['svg'],
    video: 'mp4 webm ogv mov m4v mkv'.split(' '),
    audio: 'mp3 wav ogg oga m4a aac flac opus weba'.split(' '),
    pdf: ['pdf'],
    md: 'md markdown mdx mkd'.split(' '),
    csv: 'csv tsv tab'.split(' '),
    json: 'json jsonc geojson map ipynb webmanifest'.split(' '),
    jsonl: 'jsonl ndjson'.split(' '),
    zip: 'zip docx xlsx pptx jar war apk epub odt ods odp whl vsix crx nupkg'.split(' '),
    font: 'ttf otf woff woff2'.split(' '),
    text: ('txt log text nfo ini cfg conf config env properties toml yaml yml xml html htm xhtml rss atom ' +
      'js mjs cjs jsx ts tsx json5 css scss sass less styl vue svelte astro ' +
      'py pyw rb rs go java kt kts scala swift c h cpp cc cxx hpp hh cs php pl pm lua r jl dart ex exs erl hs ml fs vb ' +
      'sh bash zsh fish ps1 bat cmd sql graphql gql proto tf tfvars hcl gradle groovy ' +
      'diff patch srt vtt pem gitignore gitattributes editorconfig lock sum mod nix vim el lisp clj cljs scm').split(' ')
  };

  function kindOf(name) {
    const e = ext(name), base = name.toLowerCase();
    for (const k in EXT) if (EXT[k].includes(e)) return k;
    if (/^(dockerfile|makefile|rakefile|gemfile|procfile|cmakelists\.txt|license|readme|changelog|\.[a-z]+rc|\.env.*)$/.test(base)) return 'text';
    return '';
  }
  function sniff(u8) {
    const h = [...u8.slice(0, 12)].map(x => x.toString(16).padStart(2, '0')).join('');
    if (h.startsWith('89504e47')) return ['image', 'PNG'];
    if (h.startsWith('ffd8ff')) return ['image', 'JPEG'];
    if (h.startsWith('47494638')) return ['image', 'GIF'];
    if (h.startsWith('25504446')) return ['pdf', 'PDF'];
    if (h.startsWith('504b0304') || h.startsWith('504b0506')) return ['zip', 'ZIP'];
    if (h.startsWith('1f8b')) return ['', 'gzip'];
    if (h.startsWith('7f454c46')) return ['', 'ELF'];
    if (h.slice(8, 16) === '66747970') return ['video', 'ISO media'];
    if (h.startsWith('4f676753')) return ['audio', 'Ogg'];
    if (h.startsWith('494433') || h.startsWith('fffb')) return ['audio', 'MP3'];
    if (h.startsWith('00010000') || h.startsWith('4f54544f') || h.startsWith('774f4646') || h.startsWith('774f4632')) return ['font', 'font'];
    return ['', ''];
  }
  function looksText(u8) {
    const n = Math.min(u8.length, 4096); if (!n) return true;
    let bad = 0;
    for (let i = 0; i < n; i++) { const c = u8[i]; if (c === 0) return false; if (c < 9 || (c > 13 && c < 32)) bad++; }
    return bad / n < 0.06;
  }
  const decode = u8 => new TextDecoder('utf-8', { fatal: false }).decode(u8).replace(/^\uFEFF/, '');

  const MIME = {
    png:'image/png', jpg:'image/jpeg', jpeg:'image/jpeg', gif:'image/gif', webp:'image/webp',
    bmp:'image/bmp', ico:'image/x-icon', avif:'image/avif', svg:'image/svg+xml',
    mp4:'video/mp4', webm:'video/webm', ogv:'video/ogg', mov:'video/quicktime', m4v:'video/mp4', mkv:'video/webm',
    mp3:'audio/mpeg', wav:'audio/wav', ogg:'audio/ogg', oga:'audio/ogg', m4a:'audio/mp4',
    aac:'audio/aac', flac:'audio/flac', opus:'audio/ogg', weba:'audio/webm',
    pdf:'application/pdf',
    ttf:'font/ttf', otf:'font/otf', woff:'font/woff', woff2:'font/woff2'
  };
  const mimeFor = e => MIME[e] || 'application/octet-stream';
  let _blobs = [];
  function blobUrl(mime) {
    const u = URL.createObjectURL(new Blob([BYTES], { type: mime }));
    _blobs.push(u);
    return u;
  }
  function freeBlobs() { _blobs.forEach(u => URL.revokeObjectURL(u)); _blobs = []; }

  function viewMedia(tag) {
    const u = blobUrl(mimeFor(ext(META.name)));
    if (tag === 'video') {
      stage.innerHTML = `<video class="view" src="${u}" controls autoplay></video>`;
      const v = stage.querySelector('video');
      const dim = tool('<span class="tag">…</span>');
      v.onloadedmetadata = () => {
        dim.textContent = v.videoWidth + ' × ' + v.videoHeight + ' · ' + fmtTime(v.duration);
      };
    } else {
      stage.innerHTML = `<div class="audiowrap"><div class="disc"></div><audio class="view" src="${u}" controls autoplay></audio></div>`;
      const a = stage.querySelector('audio');
      const dim = tool('<span class="tag">…</span>');
      a.onloadedmetadata = () => { dim.textContent = fmtTime(a.duration); };
    }
  }
  const fmtTime = s => {
    if (!isFinite(s)) return '—';
    const m = Math.floor(s / 60), sec = Math.floor(s % 60);
    return m + ':' + String(sec).padStart(2, '0');
  };

  /* ---------- toolbar ---------- */
  function buildBar(kindLabel) {
    bar.hidden = false;
    const canBack = HPOS > 0;
    bar.innerHTML =
      `<button id="b-side" class="nav" title="Show/hide file list (Ctrl+B)">&#9776;</button>` +
      `<button id="b-back" class="nav" title="Back (Alt+Left / Backspace)"${canBack ? '' : ' disabled'}>&#8592;</button>` +
      `<button id="b-fwd" class="nav" title="Forward (Alt+Right)"${HPOS >= 0 && HPOS < HISTORY.length - 1 ? '' : ' disabled'}>&#8594;</button>` +
      `<button id="b-home" class="nav" title="Home (Esc)">&#8962;</button>` +
      `<span class="name" title="${esc(META.path)}">${esc(META.name)}</span>` +
      `<span class="tag">${esc(kindLabel)}</span>` +
      `<span class="tag">${fmtSize(META.size)}</span>` +
      (META.mtime ? `<span class="tag">${new Date(META.mtime).toLocaleString()}</span>` : '') +
      `<span id="tools" style="display:flex;gap:8px;align-items:center"></span>` +
      `<span class="spacer"></span>` +
      `<button id="b-hex">Hex</button>` +
      `<button id="b-ext">Default app</button>` +
      `<button id="b-os">Reveal</button>` +
      `<button id="b-open">Open…</button>`;
    document.getElementById('b-side').onclick = toggleSidebar;
    document.getElementById('b-back').onclick = goBack;
    document.getElementById('b-fwd').onclick = goForward;
    document.getElementById('b-home').onclick = goHome;
    document.getElementById('b-hex').onclick = () => { if (BYTES) viewHex(BYTES, false); };
    document.getElementById('b-ext').onclick = () => API.openExternalApp(META.path);
    document.getElementById('b-os').onclick = () => API.reveal(META.path);
    document.getElementById('b-open').onclick = () => API.pickFile();
  }
  function tool(html) {
    const s = document.createElement('span'); s.innerHTML = html;
    document.getElementById('tools').appendChild(s);
    return s.firstElementChild;
  }

  /* ---------- dispatch ---------- */
  function render() {
    freeBlobs();
    let kind = kindOf(META.name), label = ext(META.name) ? '.' + ext(META.name) : 'unknown';
    if (!kind && BYTES) {
      const [k, l] = sniff(BYTES);
      kind = k; if (l) label = l;
      if (!kind && looksText(BYTES)) kind = 'text';
    }
    buildBar(label);
    stage.scrollTop = 0;
    try {
      switch (kind) {
        case 'image': return viewImage(false);
        case 'svg': return viewImage(true);
        case 'video': return viewMedia('video');
        case 'audio': return viewMedia('audio');
        case 'pdf': return viewPdf();
        case 'md': return viewMarkdown(decode(BYTES));
        case 'csv': return viewCSV(decode(BYTES));
        case 'json': return viewJSON(decode(BYTES));
        case 'jsonl': return viewJSONL(decode(BYTES));
        case 'zip': return viewZip(BYTES);
        case 'font': return viewFont();
        case 'text': return viewText(decode(BYTES));
        default: return viewHex(BYTES, true);
      }
    } catch (e) {
      stage.innerHTML = `<div class="pad"><p class="note">Couldn't render: ${esc(e && e.message || e)}</p></div>`;
    }
  }

  /* ---------- image ---------- */
  function viewImage(isSvg) {
    const mime = isSvg ? 'image/svg+xml' : mimeFor(ext(META.name));
    const iurl = blobUrl(mime);
    stage.innerHTML = `<img class="view" src="${iurl}"${isSvg ? ' style="max-width:96%"' : ''}>`;
    const img = stage.querySelector('img');
    const dim = tool('<span class="tag">…</span>');
    img.onload = () => { dim.textContent = img.naturalWidth + ' × ' + img.naturalHeight + ' px'; };
    img.onerror = () => { dim.textContent = 'failed to decode'; };
    let z = 0;
    const fit = tool('<button class="on">Fit</button>'), one = tool('<button>1:1</button>');
    const zi = tool('<button>+</button>'), zo = tool('<button>−</button>');
    const apply = () => {
      if (z === 0) { img.style.maxWidth = '96%'; img.style.width = ''; fit.classList.add('on'); one.classList.remove('on'); }
      else { img.style.maxWidth = 'none'; img.style.width = (img.naturalWidth * z) + 'px'; fit.classList.remove('on'); one.classList.toggle('on', z === 1); }
    };
    fit.onclick = () => { z = 0; apply(); };
    one.onclick = () => { z = 1; apply(); };
    zi.onclick = () => { z = (z || 1) * 1.5; apply(); };
    zo.onclick = () => { z = (z || 1) / 1.5; apply(); };
    if (isSvg) { const s = tool('<button>Source</button>'); s.onclick = () => viewText(decode(BYTES)); }
  }

  function viewPdf() {
    // webview iframes can't load the file: scheme; use a blob URL from the bytes
    const u = blobUrl('application/pdf');
    stage.innerHTML = `<iframe class="view" src="${u}#view=FitH"></iframe>`;
    const btn = tool('<button>Open externally</button>');
    btn.onclick = () => API.openExternalApp(META.path);
  }

  /* ---------- text ---------- */
  function viewText(t) {
    const lines = t.split(/\r\n|\r|\n/);
    const wrapBtn = tool(`<button class="${wrap ? 'on' : ''}">Wrap</button>`);
    const search = tool('<input class="search" placeholder="Find… (⏎ next)">');
    const info = tool(`<span class="tag">${lines.length.toLocaleString()} lines</span>`);
    const copy = tool('<button>Copy</button>');
    copy.onclick = () => { navigator.clipboard.writeText(t); copy.textContent = 'Copied'; setTimeout(() => copy.textContent = 'Copy', 1200); };
    const pre = document.createElement('pre');
    pre.className = 'code' + (wrap ? ' wrap' : '');
    const draw = q => {
      let hits = 0;
      pre.innerHTML = '<code>' + lines.map((l, i) => {
        let body = esc(l);
        if (q) {
          const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
          body = body.replace(re, m => { hits++; return '<mark>' + m + '</mark>'; });
        }
        return `<span class="ln">${i + 1}</span>${body}`;
      }).join('\n') + '</code>';
      info.textContent = q ? (hits + ' match' + (hits === 1 ? '' : 'es')) : (lines.length.toLocaleString() + ' lines');
    };
    draw('');
    stage.innerHTML = ''; stage.appendChild(pre);
    wrapBtn.onclick = () => { wrap = !wrap; pre.classList.toggle('wrap', wrap); wrapBtn.classList.toggle('on', wrap); };
    let tmr; search.oninput = () => { clearTimeout(tmr); search._i = -1; tmr = setTimeout(() => draw(search.value.trim()), 160); };
    search.onkeydown = e => {
      if (e.key !== 'Enter') return;
      const m = pre.querySelectorAll('mark'); if (!m.length) return;
      if (m[search._i]) m[search._i].classList.remove('cur');
      search._i = ((search._i ?? -1) + 1) % m.length;
      m[search._i].classList.add('cur');
      m[search._i].scrollIntoView({ block: 'center' });
    };
  }

  /* ---------- hex ---------- */
  function viewHex(u8, auto) {
    const CAP = META.hexBytes || 262144;
    const buf = u8.subarray(0, CAP);
    let out = '';
    for (let o = 0; o < buf.length; o += 16) {
      const row = buf.subarray(o, o + 16);
      const hex = [...row].map(b => b.toString(16).padStart(2, '0')).join(' ').padEnd(47, ' ');
      const asc = [...row].map(b => (b >= 32 && b < 127) ? String.fromCharCode(b) : '.').join('');
      out += `<span class="off">${o.toString(16).padStart(8, '0')}</span>  ${hex}  <span class="as">${esc(asc)}</span>\n`;
    }
    const head = auto ? `<p class="pad" style="color:var(--g6);padding-bottom:0">No specialized viewer for this format — raw hex dump below.</p>` : '';
    const note = u8.length > CAP ? `<p class="note pad" style="padding-top:4px">Showing first ${fmtSize(CAP)} of ${fmtSize(u8.length)}.</p>` : '';
    stage.innerHTML = head + note + '<div class="hex">' + out + '</div>';
  }

  /* ---------- CSV ---------- */
  function parseCSV(text, delim) {
    const rows = []; let row = [], cell = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) { if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c; }
      else if (c === '"') q = true;
      else if (c === delim) { row.push(cell); cell = ''; }
      else if (c === '\n') { row.push(cell); rows.push(row); row = []; cell = ''; }
      else if (c !== '\r') cell += c;
    }
    if (cell || row.length) { row.push(cell); rows.push(row); }
    return rows.filter(r => r.length > 1 || r[0] !== '');
  }
  function viewCSV(text) {
    let delim = ext(META.name) === 'csv' ? ',' : '\t';
    if (ext(META.name) === 'csv') {
      const h = text.slice(0, 4000);
      const c = (h.match(/,/g) || []).length, s = (h.match(/;/g) || []).length, t = (h.match(/\t/g) || []).length;
      delim = (s > c && s > t) ? ';' : (t > c ? '\t' : ',');
    }
    const rows = parseCSV(text, delim);
    const MAX = META.csvMaxRows || 5000;
    const hdr = rows[0] || [], body = rows.slice(1, MAX + 1);
    const isNum = v => v !== '' && !isNaN(v);
    tool(`<span class="tag">${Math.max(0, rows.length - 1).toLocaleString()} rows × ${hdr.length} cols</span>`);
    tool(`<span class="tag">delim ${delim === '\t' ? 'TAB' : delim}</span>`);
    const raw = tool('<button>Raw</button>'); raw.onclick = () => viewText(text);
    stage.innerHTML =
      `<table class="grid"><thead><tr><th class="rowh">#</th>${hdr.map(h => '<th>' + esc(h) + '</th>').join('')}</tr></thead><tbody>` +
      body.map((r, i) => '<tr><td class="rowh">' + (i + 1) + '</td>' + hdr.map((_, c) => {
        const v = r[c] ?? '';
        return `<td class="${isNum(v) ? 'num' : ''}" title="${esc(v)}">${esc(v)}</td>`;
      }).join('') + '</tr>').join('') +
      `</tbody></table>` +
      (rows.length - 1 > MAX ? `<p class="note pad">Showing first ${MAX.toLocaleString()} rows.</p>` : '');
  }

  /* ---------- JSON ---------- */
  function jsonNode(v, key) {
    const kk = key === undefined ? '' : `<span class="k">${esc(key)}</span>: `;
    if (v === null) return `<div class="kv">${kk}<span class="nl">null</span></div>`;
    if (Array.isArray(v)) {
      if (!v.length) return `<div class="kv">${kk}[]</div>`;
      return `<details open><summary>${kk}<span class="nl">[ ${v.length} ]</span></summary>${v.map((x, i) => jsonNode(x, String(i))).join('')}</details>`;
    }
    if (typeof v === 'object') {
      const ks = Object.keys(v);
      if (!ks.length) return `<div class="kv">${kk}{}</div>`;
      return `<details open><summary>${kk}<span class="nl">{ ${ks.length} }</span></summary>${ks.map(k => jsonNode(v[k], k)).join('')}</details>`;
    }
    const cls = typeof v === 'string' ? 's' : typeof v === 'number' ? 'n' : 'b';
    return `<div class="kv">${kk}<span class="${cls}">${esc(typeof v === 'string' ? JSON.stringify(v) : String(v))}</span></div>`;
  }
  function viewJSON(txt) {
    let data;
    try { data = JSON.parse(txt); }
    catch (e) {
      tool('<span class="tag" style="color:var(--g9);border-color:var(--g7)">invalid JSON</span>');
      return viewText(txt);
    }
    const raw = tool('<button>Raw</button>'), pretty = tool('<button>Pretty</button>');
    const ca = tool('<button>Collapse all</button>'), ea = tool('<button>Expand all</button>');
    raw.onclick = () => viewText(txt);
    pretty.onclick = () => viewText(JSON.stringify(data, null, 2));
    stage.innerHTML = '<div class="json pad">' + jsonNode(data) + '</div>';
    ca.onclick = () => stage.querySelectorAll('details').forEach(d => d.open = false);
    ea.onclick = () => stage.querySelectorAll('details').forEach(d => d.open = true);
  }
  function viewJSONL(txt) {
    const lines = txt.split('\n').filter(l => l.trim());
    tool(`<span class="tag">${lines.length.toLocaleString()} records</span>`);
    const html = lines.slice(0, 2000).map((l, i) => {
      let v; try { v = JSON.parse(l); } catch (e) { return `<div class="kv note">#${i + 1} invalid: ${esc(l.slice(0, 120))}</div>`; }
      return `<details><summary><span class="k">#${i + 1}</span> <span class="nl">${esc(l.slice(0, 90))}</span></summary>${jsonNode(v)}</details>`;
    }).join('');
    stage.innerHTML = '<div class="json pad">' + html + (lines.length > 2000 ? '<p class="note">Showing first 2000 records.</p>' : '') + '</div>';
  }

  /* ---------- Markdown ---------- */
  function mdToHtml(src) {
    const blocks = [];
    src = src.replace(/```[\w+-]*\n([\s\S]*?)```/g, (m, code) => {
      blocks.push('<pre><code>' + esc(code.replace(/\n$/, '')) + '</code></pre>');
      return '\u0000B' + (blocks.length - 1) + '\u0000';
    });
    const inline = s => esc(s)
      .replace(/`([^`]+)`/g, '<code>$1</code>')
      .replace(/!\[([^\]]*)\]\(([^)\s]+)[^)]*\)/g, '<img alt="$1" src="$2">')
      .replace(/\[([^\]]+)\]\(([^)\s]+)[^)]*\)/g, '<a href="$2">$1</a>')
      .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
      .replace(/(^|\W)\*([^*\n]+)\*/g, '$1<em>$2</em>')
      .replace(/~~([^~]+)~~/g, '<del>$1</del>');
    const out = [], lines = src.split('\n'); let i = 0, para = [];
    const flush = () => { if (para.length) { out.push('<p>' + inline(para.join(' ')) + '</p>'); para = []; } };
    while (i < lines.length) {
      const l = lines[i]; let m;
      if (/^\u0000B\d+\u0000$/.test(l.trim())) { flush(); out.push(blocks[+l.trim().slice(2, -1)]); i++; continue; }
      if (!l.trim()) { flush(); i++; continue; }
      if ((m = l.match(/^(#{1,6})\s+(.*)$/))) { flush(); out.push(`<h${m[1].length}>${inline(m[2])}</h${m[1].length}>`); i++; continue; }
      if (/^\s*(-{3,}|\*{3,}|_{3,})\s*$/.test(l)) { flush(); out.push('<hr>'); i++; continue; }
      if (/^\s*>/.test(l)) {
        flush(); const q = [];
        while (i < lines.length && /^\s*>/.test(lines[i])) q.push(lines[i++].replace(/^\s*>\s?/, ''));
        out.push('<blockquote>' + mdToHtml(q.join('\n')) + '</blockquote>'); continue;
      }
      if (/^\s*\|.*\|\s*$/.test(l) && /^\s*\|[\s:|-]+\|\s*$/.test(lines[i + 1] || '')) {
        flush();
        const cells = r => r.trim().replace(/^\||\|$/g, '').split('|').map(c => c.trim());
        const head = cells(lines[i]); i += 2; const rows = [];
        while (i < lines.length && /\|/.test(lines[i])) rows.push(cells(lines[i++]));
        out.push('<table><thead><tr>' + head.map(h => '<th>' + inline(h) + '</th>').join('') + '</tr></thead><tbody>' +
          rows.map(r => '<tr>' + r.map(c => '<td>' + inline(c) + '</td>').join('') + '</tr>').join('') + '</tbody></table>');
        continue;
      }
      if (/^\s*([-*+]|\d+\.)\s+/.test(l)) {
        flush(); const ol = /^\s*\d+\./.test(l); const items = [];
        while (i < lines.length && /^\s*([-*+]|\d+\.)\s+/.test(lines[i])) {
          let txt = lines[i++].replace(/^\s*([-*+]|\d+\.)\s+/, '');
          while (i < lines.length && lines[i].trim() && !/^\s*([-*+]|\d+\.)\s+/.test(lines[i]) && !/^#{1,6}\s/.test(lines[i])) txt += ' ' + lines[i++].trim();
          const box = txt.match(/^\[( |x|X)\]\s*/);
          if (box) txt = txt.slice(box[0].length);
          items.push('<li>' + (box ? `<input type="checkbox" disabled ${box[1].toLowerCase() === 'x' ? 'checked' : ''}> ` : '') + inline(txt) + '</li>');
        }
        out.push((ol ? '<ol>' : '<ul>') + items.join('') + (ol ? '</ol>' : '</ul>'));
        continue;
      }
      para.push(l.trim()); i++;
    }
    flush();
    return out.join('\n');
  }
  function viewMarkdown(src) {
    const s = tool('<button>Source</button>'); s.onclick = () => viewText(src);
    stage.innerHTML = '<div class="md">' + mdToHtml(src) + '</div>';
  }

  /* ---------- ZIP / OOXML ---------- */
  function viewZip(u8) {
    const dv = new DataView(u8.buffer, u8.byteOffset, u8.byteLength);
    let eocd = -1;
    for (let i = u8.length - 22; i >= Math.max(0, u8.length - 66000); i--) {
      if (dv.getUint32(i, true) === 0x06054b50) { eocd = i; break; }
    }
    if (eocd < 0) throw new Error('not a valid ZIP archive');
    let n = dv.getUint16(eocd + 10, true), off = dv.getUint32(eocd + 16, true);
    const entries = [], td = new TextDecoder();
    for (let i = 0; i < n && off + 46 <= u8.length; i++) {
      if (dv.getUint32(off, true) !== 0x02014b50) break;
      const method = dv.getUint16(off + 10, true), dt = dv.getUint16(off + 12, true), dd = dv.getUint16(off + 14, true);
      const csize = dv.getUint32(off + 20, true), usize = dv.getUint32(off + 24, true);
      const nlen = dv.getUint16(off + 28, true), elen = dv.getUint16(off + 30, true), clen = dv.getUint16(off + 32, true);
      const name = td.decode(u8.subarray(off + 46, off + 46 + nlen));
      const date = new Date(1980 + ((dd >> 9) & 0x7f), ((dd >> 5) & 0xf) - 1, dd & 0x1f, (dt >> 11) & 0x1f, (dt >> 5) & 0x3f, (dt & 0x1f) * 2);
      entries.push({ name, usize, csize, method, date });
      off += 46 + nlen + elen + clen;
    }
    const totalU = entries.reduce((a, e) => a + e.usize, 0), totalC = entries.reduce((a, e) => a + e.csize, 0);
    const type = { docx: 'Word document', xlsx: 'Excel workbook', pptx: 'PowerPoint deck', epub: 'EPUB book', jar: 'Java archive', apk: 'Android package', whl: 'Python wheel', vsix: 'VS Code extension', nupkg: 'NuGet package' }[ext(META.name)];
    tool(`<span class="tag">${entries.length} entries</span>`);
    const rows = entries.slice().sort((a, b) => a.name.localeCompare(b.name)).map((e, i) => {
      const dir = e.name.endsWith('/');
      return `<tr><td class="rowh">${i + 1}</td><td>${dir ? '<span class="ftype dir">DIR</span> ' : '<span class="ftype">' + esc((e.name.split('.').pop().length < 5 && e.name.includes('.') ? e.name.split('.').pop() : '\u2013').toUpperCase().slice(0,4)) + '</span> '}${esc(e.name)}</td>` +
        `<td class="num">${dir ? '' : fmtSize(e.usize)}</td><td class="num">${dir ? '' : fmtSize(e.csize)}</td>` +
        `<td class="num">${dir || !e.usize ? '' : Math.round(100 - 100 * e.csize / e.usize) + '%'}</td>` +
        `<td>${isNaN(e.date) ? '' : e.date.toLocaleString()}</td>` +
        `<td>${e.method === 0 ? 'stored' : e.method === 8 ? 'deflate' : 'm' + e.method}</td></tr>`;
    }).join('');
    stage.innerHTML =
      `<div class="pad"><h3 class="sec">Archive${type ? ' — ' + type : ''}</h3>` +
      `<table class="kvtable"><tr><td>Entries</td><td>${entries.length}</td></tr>` +
      `<tr><td>Uncompressed</td><td>${fmtSize(totalU)}</td></tr>` +
      `<tr><td>Compressed</td><td>${fmtSize(totalC)} (${totalU ? Math.round(100 - 100 * totalC / totalU) : 0}% saved)</td></tr></table>` +
      `<h3 class="sec">Contents</h3></div>` +
      `<table class="grid"><thead><tr><th class="rowh">#</th><th>Path</th><th>Size</th><th>Packed</th><th>Ratio</th><th>Modified</th><th>Method</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  /* ---------- fonts ---------- */
  function viewFont() {
    const fam = 'oa' + Date.now().toString(36);
    const u = blobUrl(mimeFor(ext(META.name)) || 'font/ttf');
    const st = document.createElement('style');
    st.textContent = `@font-face{font-family:"${fam}";src:url("${u}")}`;
    document.head.appendChild(st);
    const pangram = 'The quick brown fox jumps over the lazy dog.';
    stage.innerHTML = `<div class="pad" style="font-family:'${fam}',sans-serif">` +
      [64, 42, 30, 22, 17, 13].map(s =>
        `<div class="spec"><span class="sz">${s}px</span><br><span style="font-size:${s}px">${esc(pangram)}</span></div>`).join('') +
      ['ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz', '0123456789 !?@#$%&*()[]{}/\\'].map(s =>
        `<div style="font-size:26px;margin:10px 0;word-break:break-all">${esc(s)}</div>`).join('') +
      `<div class="typebox" contenteditable spellcheck="false">Type here to preview…</div></div>`;
  }

  
  /* ---------- loading ---------- */
  async function load(filePath, fromHistory) {
    CURPATH = filePath;
    if (!fromHistory) {
      // drop any forward entries, then push
      if (HPOS < HISTORY.length - 1) HISTORY = HISTORY.slice(0, HPOS + 1);
      if (HISTORY[HPOS] !== filePath) { HISTORY.push(filePath); HPOS = HISTORY.length - 1; }
    }
    // recents: move-to-front, capped, survives history truncation
    RECENT = RECENT.filter(p => p !== filePath);
    RECENT.push(filePath);
    if (RECENT.length > 12) RECENT.shift();
    saveRecent();
    renderSidebar();
    stage.innerHTML = '<div class="center">Reading…</div>';
    try {
      const r = await API.readFile(filePath);
      META = r.meta;
      META.hexBytes = 262144;
      META.csvMaxRows = 5000;
      if (r.tooBig) {
        buildBar('too large');
        stage.innerHTML = '<div class="center"><div><p>This file is ' + fmtSize(META.size) +
          ', above the ' + fmtSize(r.maxBytes) + ' limit.</p>' +
          '<p style="color:var(--g6)">Use <b>Open in default app</b> instead.</p></div></div>';
        return;
      }
      BYTES = new Uint8Array(r.bytes);
      render();
      renderSidebar();
    } catch (e) {
      bar.hidden = true;
      stage.innerHTML = '<div class="center note">Could not read this file.<br>' + esc(e && e.message || e) + '</div>';
    }
  }

  /* ---------- sidebar ---------- */
  function baseName(p) { return p.split(/[\\/]/).pop(); }
  function dirName(p) {
    const parts = p.split(/[\\/]/); parts.pop();
    return parts.join('\\') || '';
  }
  function extBadge(name) {
    const e = ext(name);
    return e ? e.toUpperCase().slice(0, 4) : '\u2013';
  }

  function renderSidebar() {
    if (!side) return;
    // Visibility is controlled ONLY by the user's toggle, never by list length —
    // otherwise emptying the list would leave no way to reopen the panel.
    side.hidden = !SIDEBAR;
    const cnt = document.getElementById('sidecount');
    if (cnt) cnt.textContent = RECENT.length ? String(RECENT.length) : '';
    const cbtn = document.getElementById('s-clear');
    if (cbtn) cbtn.disabled = RECENT.length === 0;
    if (side.hidden) return;

    if (RECENT.length === 0) {
      sidelist.innerHTML =
        '<div class="sempty">No files yet.<br><span>Drop a file anywhere, ' +
        'or use Open file below.</span></div>';
      return;
    }

    const items = RECENT.slice().reverse();
    sidelist.innerHTML = items.map(p => {
      const sel = (p === CURPATH) ? ' sel' : '';
      return `<div class="sitem${sel}" data-p="${esc(p)}" title="${esc(p)}">
        <span class="sico">${esc(extBadge(baseName(p)))}</span>
        <span class="smeta">
          <span class="sname">${esc(baseName(p))}</span>
          <span class="spath">${esc(dirName(p))}</span>
        </span>
        <span class="sx" data-x="${esc(p)}" title="Remove from list">&#215;</span>
      </div>`;
    }).join('');

    sidelist.querySelectorAll('.sitem').forEach(el => {
      el.onclick = (e) => {
        if (e.target.classList.contains('sx')) return;
        if (el.dataset.p !== CURPATH) load(el.dataset.p);
      };
    });
    sidelist.querySelectorAll('.sx').forEach(x => {
      x.onclick = (e) => { e.stopPropagation(); removeRecent(x.dataset.x); };
    });

    const selEl = sidelist.querySelector('.sitem.sel');
    if (selEl) selEl.scrollIntoView({ block: 'nearest' });
  }

  function toggleSidebar() {
    SIDEBAR = !SIDEBAR;
    try { localStorage.setItem('openany.sidebar', SIDEBAR ? '1' : '0'); } catch (_) {}
    renderSidebar();
  }

  // sidebar buttons
  const sOpen = document.getElementById('s-open');
  if (sOpen) sOpen.onclick = () => API.pickFile();
  const sClear = document.getElementById('s-clear');
  if (sClear) sClear.onclick = clearRecent;

  // drag-to-resize
  (function () {
    if (!side) return;
    const grip = document.createElement('div');
    grip.id = 'sidegrip';
    side.appendChild(grip);
    let dragging = false;
    grip.addEventListener('mousedown', e => { dragging = true; e.preventDefault(); document.body.style.cursor = 'col-resize'; });
    window.addEventListener('mousemove', e => {
      if (!dragging) return;
      const w = Math.min(460, Math.max(150, e.clientX));
      side.style.flex = '0 0 ' + w + 'px';
      side.style.width = w + 'px';
    });
    window.addEventListener('mouseup', () => {
      if (!dragging) return;
      dragging = false; document.body.style.cursor = '';
      try { localStorage.setItem('openany.sidewidth', String(parseInt(side.style.width, 10) || 230)); } catch (_) {}
    });
  })();

  /* ---------- navigation ---------- */
  try {
    const saved = JSON.parse(localStorage.getItem('openany.recent') || '[]');
    if (Array.isArray(saved)) RECENT = saved.filter(x => typeof x === 'string').slice(-12);
    if (localStorage.getItem('openany.sidebar') === '0') SIDEBAR = false;
    const sw = parseInt(localStorage.getItem('openany.sidewidth') || '0', 10);
    if (side && sw >= 150 && sw <= 460) { side.style.flex = '0 0 ' + sw + 'px'; side.style.width = sw + 'px'; }
  } catch (_) {}
  function goBack() {
    if (HPOS > 0) { HPOS--; load(HISTORY[HPOS], true); }
    else goHome();
  }
  function goForward() {
    if (HPOS >= 0 && HPOS < HISTORY.length - 1) { HPOS++; load(HISTORY[HPOS], true); }
  }
  function goHome() {
    CURPATH = null; META = null; BYTES = null;
    freeBlobs();
    bar.hidden = true;
    bar.innerHTML = '';
    stage.scrollTop = 0;
    stage.innerHTML = welcomeHTML();
    wireWelcome();
    renderSidebar();
    API.setTitle('OpenAny');
  }
  function welcomeHTML() {
    const recent = RECENT.slice(-8).reverse();
    const list = recent.length
      ? `<div class="recent">
           <div class="rhead">
             <span class="rlabel">Recent</span>
             <button id="r-clear" class="rclear" title="Remove all files from this list">Clear list</button>
           </div>` +
        recent.map(p => {
          const nm = p.split(/[\\/]/).pop();
          return `<span class="ritem" data-p="${esc(p)}" title="${esc(p)}">` +
                 `<span class="rname">${esc(nm)}</span>` +
                 `<span class="rx" data-x="${esc(p)}" title="Remove from list">&#215;</span>` +
                 `</span>`;
        }).join('') + `</div>`
      : '';
    return `<div class="welcome">
      <img src="icon.png" class="mark" alt="">
      <div class="wtitle">OpenAny</div>
      <div class="wsub">Drop a file here to open it</div>
      <div class="wbtns">
        <button id="w-open">Open file…</button>
        <button id="w-new">New window</button>
        <button id="w-uninstall" class="danger">Uninstall</button>
      </div>
      ${list}
      <div class="wlist">
        Images · SVG · Video · Audio · PDF · Text &amp; 90+ code languages · Markdown ·
        CSV/TSV · JSON/JSONL · XML · ZIP, docx, xlsx, pptx, jar, epub ·
        Fonts · everything else as a hex dump
      </div>
      <div class="wfoot">Files are read locally. Nothing leaves this machine.</div>
    </div>`;
  }
  function wireWelcome() {
    const o = document.getElementById('w-open'), n = document.getElementById('w-new');
    if (o) o.onclick = () => API.pickFile();
    if (n) n.onclick = () => API.newWindow();
    const un = document.getElementById('w-uninstall');
    if (un) un.onclick = () => API.uninstall();

    // open a recent file
    stage.querySelectorAll('.ritem').forEach(b => {
      b.onclick = (e) => {
        if (e.target.classList.contains('rx')) return;   // the × handles itself
        load(b.dataset.p);
      };
    });

    // remove a single entry
    stage.querySelectorAll('.rx').forEach(x => {
      x.onclick = (e) => {
        e.stopPropagation();
        removeRecent(x.dataset.x);
      };
    });

    // clear the whole list
    const c = document.getElementById('r-clear');
    if (c) c.onclick = clearRecent;
  }

  function saveRecent() {
    try { localStorage.setItem('openany.recent', JSON.stringify(RECENT)); } catch (_) {}
  }
  function repaintWelcome() {
    renderSidebar();
    if (!document.querySelector('.welcome')) return;
    stage.innerHTML = welcomeHTML();
    wireWelcome();
  }
  function removeRecent(p) {
    RECENT = RECENT.filter(x => x !== p);
    saveRecent();
    repaintWelcome();
  }
  function clearRecent() {
    RECENT = [];
    HISTORY = [];
    HPOS = -1;
    saveRecent();
    repaintWelcome();
  }

  /* ---------- welcome wiring ---------- */
  if (RECENT.length && document.querySelector('.welcome')) {
    stage.innerHTML = welcomeHTML();   // repaint with restored recents
  }
  wireWelcome();
  renderSidebar();

  /* ---------- drag & drop ---------- */
  let depth = 0;
  window.addEventListener('dragenter', e => { e.preventDefault(); depth++; document.body.classList.add('dragging'); });
  window.addEventListener('dragover', e => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
  window.addEventListener('dragleave', e => { e.preventDefault(); if (--depth <= 0) { depth = 0; document.body.classList.remove('dragging'); } });
  window.addEventListener('drop', e => {
    e.preventDefault(); depth = 0; document.body.classList.remove('dragging');
    const paths = [...(e.dataTransfer.files || [])].map(f => API.pathForFile(f)).filter(Boolean);
    if (paths.length) API.openPaths(paths);
  });

  /* ---------- IPC events ---------- */
  API.onOpenFile(p => load(p));
  API.onFileChanged(() => { if (CURPATH) load(CURPATH); });
  API.onMenu(action => {
    if (action === 'open') API.pickFile();
    else if (action === 'reveal') { if (CURPATH) API.reveal(CURPATH); }
    else if (action === 'external') { if (CURPATH) API.openExternalApp(CURPATH); }
    else if (action === 'hex') { if (BYTES) viewHex(BYTES, false); }
    else if (action === 'find') { const s = document.querySelector('input.search'); if (s) { s.focus(); s.select(); } }
    else if (action === 'back') goBack();
    else if (action === 'forward') goForward();
    else if (action === 'home') goHome();
    else if (action === 'clear-recent') { clearRecent(); if (!CURPATH) repaintWelcome(); }
    else if (action === 'toggle-sidebar') toggleSidebar();
    else if (action === 'uninstall') API.uninstall();
  });

  window.addEventListener('keydown', e => {
    const inField = /^(INPUT|TEXTAREA)$/.test(e.target.tagName) || e.target.isContentEditable;
    if (e.key === 'Escape') {
      const s = document.querySelector('input.search');
      if (s && document.activeElement === s) { s.blur(); return; }
      if (CURPATH) { goHome(); return; }
    }
    if ((e.ctrlKey || e.metaKey) && (e.key === 'b' || e.key === 'B')) { e.preventDefault(); toggleSidebar(); return; }
    if (e.altKey && e.key === 'ArrowLeft') { e.preventDefault(); goBack(); return; }
    if (e.altKey && e.key === 'ArrowRight') { e.preventDefault(); goForward(); return; }
    if (e.key === 'Backspace' && !inField) { e.preventDefault(); goBack(); return; }
    if (e.key === 'BrowserBack') { goBack(); return; }
  });

  // mouse button 3/4 = back/forward, like a browser
  window.addEventListener('mouseup', e => {
    if (e.button === 3) { e.preventDefault(); goBack(); }
    if (e.button === 4) { e.preventDefault(); goForward(); }
  });
})();
