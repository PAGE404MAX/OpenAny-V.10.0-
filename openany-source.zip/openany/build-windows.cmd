@echo off
REM ============================================
REM  OpenAny - build the Windows installer
REM  Requires Node.js 18+  (https://nodejs.org)
REM ============================================
setlocal
cd /d "%~dp0"

where node >nul 2>nul
if errorlevel 1 (
  echo [!] Node.js not found. Install it from https://nodejs.org then re-run this file.
  pause
  exit /b 1
)

echo.
echo === Installing dependencies (first run takes a few minutes) ===
call npm install --no-audit --no-fund
if errorlevel 1 goto fail

echo.
echo === Building OpenAny for Windows ===
call npx electron-builder --win --x64
if errorlevel 1 goto fail

echo.
echo ================================================
echo  Done. Look in the "release" folder for:
echo    OpenAny-Setup-1.0.0.exe     (installer)
echo    OpenAny-Portable-1.0.0.exe  (no install)
echo ================================================
start "" "%~dp0release"
pause
exit /b 0

:fail
echo.
echo [!] Build failed. Scroll up for the error.
pause
exit /b 1
