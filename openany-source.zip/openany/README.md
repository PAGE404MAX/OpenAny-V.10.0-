<div align="center">

<img src="src/icon.png" width="120" alt="OpenAny">

# OpenAny

**A universal file viewer. Open any file type — in its own window.**

No more *"The file is not displayed because it is either binary or uses an unsupported encoding."*

[![Build Windows app](https://github.com/YOUR-YOUR-USERNAME/openany/actions/workflows/build.yml/badge.svg)](https://github.com/YOUR-YOUR-USERNAME/openany/actions/workflows/build.yml)
[![License: MIT](https://img.shields.io/badge/License-MIT-lightgrey.svg)](LICENSE)

</div>

---

## Download

Grab the latest **`OpenAny-Setup-*.exe`** from the [Releases page](../../releases).

- No admin rights required — installs to your user folder
- Windows SmartScreen will warn that the app is unsigned → **More info → Run anyway**
- Prefer no installer? Use **`OpenAny-Portable-*.exe`**

---

## Screenshots

<div align="center">

| Home screen | Markdown |
|---|---|
| <img src="docs/screenshot-home.png" width="400"> | <img src="docs/screenshot-markdown.png" width="400"> |

**Archive contents**

<img src="docs/screenshot-archive.png" width="700">

</div>

---

## What it opens

| Type | Viewer |
|---|---|
| **Images** — png, jpg, gif, webp, avif, bmp, ico | zoom / fit / 1:1, alpha checkerboard, pixel dimensions |
| **SVG** | rendered + source toggle |
| **Video** — mp4, webm, mov, mkv | player with resolution + duration |
| **Audio** — mp3, wav, flac, ogg, m4a | player with duration |
| **PDF** | embedded viewer |
| **Text & code** — 100 extensions | line numbers, find with match count, wrap, copy |
| **Markdown** | tables, task lists, code fences, blockquotes |
| **CSV / TSV** | quote-aware parser, delimiter auto-detect, sticky headers |
| **JSON / GeoJSON / .ipynb** | collapsible tree, expand/collapse all, pretty-print |
| **JSONL / NDJSON** | per-record tree |
| **Archives** — zip, docx, xlsx, pptx, jar, apk, epub, whl | entry listing with sizes, ratios, timestamps |
| **Fonts** — ttf, otf, woff, woff2 | specimen at 6 sizes + editable preview |
| **Everything else** | magic-byte detection, then a hex dump |

**161 file extensions** mapped. Files with no extension are identified by
**magic bytes** (PNG, ELF, gzip, Ogg, ISO media…), known bare names
(`Dockerfile`, `Makefile`, `.env`…), then a binary-vs-text heuristic.

---

## Features

- **One window per file**, titled with the file name
- **Recent files sidebar** — click to switch, `×` to remove, drag to resize, `Ctrl+B` to hide
- **Back / forward / home** navigation with history
- **Live reload** when a file changes on disk
- **Pure greyscale UI** — a 10-step ramp, zero colour, zero emoji
- **Single instance** — double-clicking more files routes them to the running app
- **Offline by design** — `default-src 'none'`, no network access whatsoever

### Keyboard

| Key | Action |
|---|---|
| `Ctrl+O` / `Ctrl+N` | Open file / new window |
| `Ctrl+B` | Toggle file list |
| `Ctrl+F` | Find in text |
| `Ctrl+H` | Force hex dump |
| `Ctrl+R` | Reload from disk |
| `Esc` | Home |
| `Backspace` / `Alt+←` | Back |
| `Alt+→` | Forward |

---

## Build it yourself

Requires [Node.js](https://nodejs.org) 18+.

```bash
git clone https://github.com/YOUR-YOUR-USERNAME/openany.git
cd openany
npm install

npm start          # run from source
npm run dist       # build installer + portable exe into release/
```

On Windows you can also just double-click **`build-windows.cmd`**.

### Building on Linux (no Wine)

`electron-builder` normally needs Wine to produce a Windows installer.
This repo works around that:

```bash
./build-installer-linux.sh
```

It packages the app, runs `stamp-icon.py` to embed the icon and rename the
executable's version strings using a pure-Python PE editor, then drives the
NSIS Linux binary directly against `installer.nsi`.

---

## Project layout

```
src/
  main.js        window management, file watching, IPC, menus
  preload.js     locked-down contextBridge API
  index.html     app shell
  viewer.css     greyscale theme
  viewer.js      all format viewers
assets/icon.ico  Windows icon (16→256px)
installer.nsi    NSIS installer script
stamp-icon.py    pure-python PE icon/metadata editor
.github/workflows/build.yml   CI: builds + publishes releases
```

---

## Security

`contextIsolation: true`, `nodeIntegration: false`, strict CSP, in-app
navigation blocked, external links forced to the system browser. Filesystem
access goes through 8 explicit IPC channels — the UI never touches `fs`.

## Known limitations

- Archive contents are **listed, not extracted** — you can't yet click into a zip entry
- No syntax-highlighting colours in code view (greyscale by design)
- Prebuilt binaries are Windows x64; the source runs on macOS and Linux too

## License

MIT — see [LICENSE](LICENSE).
