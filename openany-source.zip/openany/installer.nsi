Unicode true
!include "MUI2.nsh"
!include "FileFunc.nsh"

!define APP    "OpenAny"
!define VER    "1.0.0"
!define PUB    "OpenAny"
!define EXE    "OpenAny.exe"

Name "${APP} ${VER}"
OutFile "${OUTFILE}"
InstallDir "$LOCALAPPDATA\Programs\OpenAny"
InstallDirRegKey HKCU "Software\${APP}" "InstallDir"
RequestExecutionLevel user
SetCompressor /SOLID lzma
SetCompressorDictSize 8
BrandingText "${APP} ${VER}"

!define MUI_ICON   "${ICONFILE}"
!define MUI_UNICON "${ICONFILE}"
!define MUI_ABORTWARNING
!define MUI_FINISHPAGE_RUN "$INSTDIR\${EXE}"
!define MUI_FINISHPAGE_RUN_TEXT "Launch ${APP}"
!define MUI_FINISHPAGE_LINK "Drop any file on the window to open it"

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

VIProductVersion "1.0.0.0"
VIAddVersionKey "ProductName"     "${APP}"
VIAddVersionKey "FileDescription" "${APP} Setup"
VIAddVersionKey "FileVersion"     "${VER}"
VIAddVersionKey "ProductVersion"  "${VER}"
VIAddVersionKey "CompanyName"     "${PUB}"
VIAddVersionKey "LegalCopyright"  "Copyright (C) 2026 ${PUB}"

; ---- register one file extension for "Open with" ----
!macro RegExt EXT
  WriteRegStr HKCU "Software\Classes\.${EXT}\OpenWithProgids" "OpenAny.Document" ""
!macroend

Section "Install"
  SetOutPath "$INSTDIR"
  File /r "${PAYLOAD}\*.*"

  ; ProgID used by the Open-with list
  WriteRegStr HKCU "Software\Classes\OpenAny.Document" "" "OpenAny document"
  WriteRegStr HKCU "Software\Classes\OpenAny.Document\DefaultIcon" "" "$INSTDIR\${EXE},0"
  WriteRegStr HKCU "Software\Classes\OpenAny.Document\shell\open\command" "" '"$INSTDIR\${EXE}" "%1"'

  ; "Open with OpenAny" on every file type
  WriteRegStr HKCU "Software\Classes\*\shell\OpenAny" "" "Open with OpenAny"
  WriteRegStr HKCU "Software\Classes\*\shell\OpenAny" "Icon" "$INSTDIR\${EXE},0"
  WriteRegStr HKCU "Software\Classes\*\shell\OpenAny\command" "" '"$INSTDIR\${EXE}" "%1"'

  ; Applications entry so it shows in "Choose another app"
  WriteRegStr HKCU "Software\Classes\Applications\${EXE}\shell\open\command" "" '"$INSTDIR\${EXE}" "%1"'
  WriteRegStr HKCU "Software\Classes\Applications\${EXE}" "FriendlyAppName" "OpenAny"

  !insertmacro RegExt "zip"
  !insertmacro RegExt "jar"
  !insertmacro RegExt "epub"
  !insertmacro RegExt "docx"
  !insertmacro RegExt "xlsx"
  !insertmacro RegExt "pptx"
  !insertmacro RegExt "ttf"
  !insertmacro RegExt "otf"
  !insertmacro RegExt "woff"
  !insertmacro RegExt "woff2"
  !insertmacro RegExt "csv"
  !insertmacro RegExt "tsv"
  !insertmacro RegExt "json"
  !insertmacro RegExt "jsonl"
  !insertmacro RegExt "ndjson"
  !insertmacro RegExt "md"
  !insertmacro RegExt "log"
  !insertmacro RegExt "bin"
  !insertmacro RegExt "dat"
  !insertmacro RegExt "db"
  !insertmacro RegExt "sqlite"
  !insertmacro RegExt "toml"
  !insertmacro RegExt "ini"
  !insertmacro RegExt "srt"
  !insertmacro RegExt "vtt"
  !insertmacro RegExt "geojson"

  ; shortcuts
  CreateDirectory "$SMPROGRAMS\${APP}"
  CreateShortCut  "$SMPROGRAMS\${APP}\${APP}.lnk" "$INSTDIR\${EXE}" "" "$INSTDIR\${EXE}" 0
  CreateShortCut  "$DESKTOP\${APP}.lnk"           "$INSTDIR\${EXE}" "" "$INSTDIR\${EXE}" 0

  ; uninstall info
  WriteUninstaller "$INSTDIR\Uninstall.exe"
  WriteRegStr HKCU "Software\${APP}" "InstallDir" "$INSTDIR"
  !define UNKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APP}"
  WriteRegStr HKCU "${UNKEY}" "DisplayName"     "${APP}"
  WriteRegStr HKCU "${UNKEY}" "DisplayVersion"  "${VER}"
  WriteRegStr HKCU "${UNKEY}" "Publisher"       "${PUB}"
  WriteRegStr HKCU "${UNKEY}" "DisplayIcon"     "$INSTDIR\${EXE}"
  WriteRegStr HKCU "${UNKEY}" "UninstallString" '"$INSTDIR\Uninstall.exe"'
  WriteRegStr HKCU "${UNKEY}" "InstallLocation" "$INSTDIR"
  WriteRegDWORD HKCU "${UNKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNKEY}" "NoRepair" 1
  ${GetSize} "$INSTDIR" "/S=0K" $0 $1 $2
  IntFmt $0 "0x%08X" $0
  WriteRegDWORD HKCU "${UNKEY}" "EstimatedSize" "$0"

  System::Call 'shell32::SHChangeNotify(i 0x8000000, i 0, i 0, i 0)'
SectionEnd

Section "Uninstall"
  Delete "$DESKTOP\${APP}.lnk"
  Delete "$SMPROGRAMS\${APP}\${APP}.lnk"
  RMDir  "$SMPROGRAMS\${APP}"
  RMDir /r "$INSTDIR"
  DeleteRegKey HKCU "Software\Classes\OpenAny.Document"
  DeleteRegKey HKCU "Software\Classes\*\shell\OpenAny"
  DeleteRegKey HKCU "Software\Classes\Applications\${EXE}"
  DeleteRegKey HKCU "Software\${APP}"
  DeleteRegKey HKCU "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APP}"
  System::Call 'shell32::SHChangeNotify(i 0x8000000, i 0, i 0, i 0)'
SectionEnd
